﻿Select top 1 end_pixel from purchase_user order by end_pixel desc;

delete from purchase_user